package com.hangaries.repository;

import com.hangaries.model.CustomerDtls;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerDtlsRepository extends JpaRepository<CustomerDtls, Long> {
    @Query(value = "select count(*) from CUSTOMER_ADDRESS_DETAILS where mobile_number=:mobnumber and customer_address_type=:type", nativeQuery = true)
    public int getCustomerStatus(@Param("mobnumber") String mobnumber, @Param("type") String type) throws Exception;

    @Query(value = "select * from CUSTOMER_ADDRESS_DETAILS where mobile_number=:mobnumber and customer_address_type=:type", nativeQuery = true)
    public CustomerDtls getCustometDtlsById(@Param("mobnumber") String mobnumber, @Param("type") String type) throws Exception;
}
