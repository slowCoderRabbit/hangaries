 package com.hangaries.service.menuDishpointService;

public interface MenuDishpointService {

}

