package com.hangaries.service.customerService;


import com.hangaries.model.Customer;

public interface CustomerService {
    public void  registerCustomer(String mobnum) throws Exception;
    public void updateCustomerInfo(Customer customer)throws Exception;
}
