package com.hangaries.service.customerService.Impl;

import com.hangaries.controller.CustomerDtlsController;
import com.hangaries.model.Customer;
import com.hangaries.repository.CustomerRepository;
import com.hangaries.service.customerService.CustomerService;
import jdk.jfr.events.ExceptionThrownEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
@Service
public class CustomerServiceImpl implements CustomerService {
    private static final Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);

    @Autowired
    private CustomerRepository customerRepository;

    public void registerCustomer(String mobnum) throws Exception {
        try {
            Customer customer=new Customer();
            int count = customerRepository.getCustomerRegisterStatus(mobnum);
            if(count==0){
                customer.setMobileNumber(mobnum);
                customer.setFirstName("");
                customerRepository.save(customer);
            }
        } catch (Exception ex) {
            logger.error("Error while saving registration details::"+ex.getMessage());
            throw new Exception(ex);
        }
    }
    public void updateCustomerInfo(Customer customer)throws  Exception{
        try{
            long customerId=customerRepository.getCustomerIdByMobNo(customer.getMobileNumber());
            Customer customerUpdate=customerRepository.getOne(customerId);
            customerUpdate.setEmailId(customer.getEmailId());
            customerUpdate.setFirstName(customer.getFirstName());
            customerUpdate.setLastName(customer.getLastName());
            customerUpdate.setCreatedBy(customer.getCreatedBy());
            customerUpdate.setAlternativeContactId(customer.getAlternativeContactId());
            customerUpdate.setRestaurantId(customer.getRestaurantId());
            customerUpdate.setCustomerActiveStatus(customer.getCustomerActiveStatus());
            customerUpdate.setMiddleName(customer.getMiddleName());
            customerUpdate.setRestaurantId(customer.getRestaurantId());
        }catch (Exception ex){
            throw new Exception(ex);
        }
    }

}
