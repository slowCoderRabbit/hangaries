package com.hangaries.service;


public interface CustomerService {
}
