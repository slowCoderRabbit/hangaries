package com.hangaries.service.menuService;

import com.hangaries.model.Menu;

import java.util.List;

public interface MenuService {
    List<Menu>getAllMenuItems() throws Exception;
}