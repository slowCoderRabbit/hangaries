package com.hangaries.service.impl;

public class CustomerServiceImpl {
}
