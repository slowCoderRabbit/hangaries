package com.hangaries.service.customerDtlsService;

import com.hangaries.model.CustomerDtls;
import org.springframework.stereotype.Service;

@Service
public interface CustomerDtlsService {

    public void saveCustomerDtls(CustomerDtls customerDtls)throws Exception;
    public void updateCustomerDtls(CustomerDtls customerDtls)throws Exception;
}
