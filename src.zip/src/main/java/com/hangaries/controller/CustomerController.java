package com.hangaries.controller;


import com.hangaries.constants.Status;
import com.hangaries.model.Customer;
import com.hangaries.repository.CustomerRepository;
import com.hangaries.service.customerService.Impl.CustomerServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import java.util.List;


@RestController
@RequestMapping("/api")
public class CustomerController {

    private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

    @Autowired
    CustomerRepository customerRepository;
    @Autowired
    CustomerServiceImpl customerService;

    ValidatorFactory factory = Validation.buildDefaultValidatorFactory();

    @GetMapping("/customer/register")
    public ResponseEntity<String> registerCustomer(@RequestParam("mobno") String mobno) {
        try {
            logger.info("Register mobile number: " + mobno);
            customerService.registerCustomer(mobno);
            return new ResponseEntity<String>("Success", HttpStatus.OK);
        } catch (Exception ex) {
            logger.error("Error while registering customer::" + ex.getMessage());
            return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/customer/update")
    public ResponseEntity<String> updateCustomer(@Valid @RequestBody Customer newCustomer) {
        try {
            customerService.updateCustomerInfo(newCustomer);
            return new ResponseEntity<String>("Success", HttpStatus.OK);
        } catch (Exception ex) {
            logger.error("Error while updating customer infor::" + ex.getMessage());
            return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("/customer/loginId")
    ResponseEntity getCustomerByLoginId() {

       // ResponseEntity responseEntity = new ResponseEntity<List<Customer>>(customerRepository.findByLoginId("hungries"), HttpStatus.OK);
        return null;

    }

    @GetMapping("/customer/getDtlsbyId")
    List<Customer> getCustomersById() {
        Long id = 1L;
        List<Customer> customers = customerRepository.findAll();
        return customers;
    }

    @DeleteMapping("/customer/loginId")
    ResponseEntity deleteCustomerByLoginId(@RequestParam String loginId) {
       // ResponseEntity responseEntity = new ResponseEntity<List<Customer>>(customerRepository.deleteByLoginId(loginId), HttpStatus.OK);
        return null;
    }

    @GetMapping("/customer/register1")
    Status registerCustomer() {
        Customer customer=new Customer();
        customer.setId(12);
        customer.setEmailId("ranjan.ab@gmail.com");
        customer.setMobileNumber("9199911");
        customer.setFirstName("Abhishek");
        customer.setMiddleName("Ranjan");
        customer.setCustomerActiveStatus("Yes");
        customer.setLastName("RRR");
         logger.info("New user: " + customer.toString());

        customerRepository.save(customer);
        return Status.SUCCESS;

    }
}
