package com.hangaries.controller;

import com.hangaries.model.CustomerDtls;
import com.hangaries.service.customerDtlsService.Impl.CustomerDtlsServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CustomerDtlsController {
    private static final Logger logger = LoggerFactory.getLogger(CustomerDtlsController.class);

    @Autowired
    private CustomerDtlsServiceImpl customerDtlsService;
    @PostMapping("saveCustomerDtls")
    @ResponseBody
    public ResponseEntity<String> saveCustomerDtls(@RequestBody CustomerDtls customerDtls) throws Exception {
        try {
            logger.info("save customer details::");
            customerDtlsService.saveCustomerDtls(customerDtls);
            return new ResponseEntity<String>("Success", HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<String>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
