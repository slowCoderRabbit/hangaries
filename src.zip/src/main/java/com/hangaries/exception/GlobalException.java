package com.hangaries.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

public class GlobalException {

}
