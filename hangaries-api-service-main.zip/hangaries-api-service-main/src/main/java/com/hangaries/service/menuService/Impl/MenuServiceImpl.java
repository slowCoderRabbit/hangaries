package com.hangaries.service.menuService.Impl;

import com.hangaries.controller.MenuController;
import com.hangaries.model.Menu;
import com.hangaries.repository.MenuRepository;
import com.hangaries.service.menuService.MenuService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ExecutionException;

@Service
public class MenuServiceImpl implements MenuService {
    private static final Logger logger = LoggerFactory.getLogger(MenuServiceImpl.class);

    @Autowired
    private MenuRepository menuRepository;

    public List<Menu> getAllMenuItems() throws Exception {
        logger.debug("Inside menu service::");
        List<Menu> menuList=null;
        try {
            menuList = menuRepository.getAllMenuItems();
        }catch (Exception ex){
            logger.error("Error while getting menuitems::"+ex.getMessage());
        }
        return menuList;
    }
}